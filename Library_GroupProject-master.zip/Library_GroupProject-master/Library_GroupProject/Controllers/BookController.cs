﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Library.Core.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Library_GroupProject.Controllers
{
    public class BookController : Controller
    {
        private readonly IBookRepository _books;
        private readonly ITransactionRepository _transactions;
        private readonly ICustomerRepository _customers;

        public BookController(IBookRepository bookRepository, ICustomerRepository customerRepository, ITransactionRepository transactionRepository)
        {
            _books = bookRepository;
            _customers = customerRepository;
            _transactions = transactionRepository;
        }

        public IActionResult List()
        {
            return View(_books.AllBooks);
        }
        
        public IActionResult Add()
        {
            return View();
        }
        
        public IActionResult Details(int id)
        {
            var book = _books.GetBookById(id);

            return View("../Book/Details", book);
        }

        [HttpPost]
        public IActionResult Add(BookViewModel model)
        {
            if (ModelState.IsValid)
            {
                var book = new Book();
                book.Title = model.Title;
                book.AuthorFirstName = model.AuthorFirstName;
                book.AuthorLastName = model.AuthorLastName;
                book.Price = model.Price;
                _books.Add(book);
                model.Title = "";
                model.AuthorFirstName = "";
                model.AuthorLastName = "";
                model.Price = 0;
                model.Success = true;
                ModelState.Clear();
            }

            return View(model);
        }
    }
}
