﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Library.Core.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Library_GroupProject.Controllers
{
    public class CustomerController : Controller
    {
        private readonly IBookRepository _books;
        private readonly ITransactionRepository _transactions;
        private readonly ICustomerRepository _customers;

        public CustomerController(IBookRepository bookRepository, ITransactionRepository transactionRepository, ICustomerRepository customerRepository)
        {
            _books = bookRepository;
            _transactions = transactionRepository;
            _customers = customerRepository;
        }
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(CustomerViewModel model)
        {
            if (ModelState.IsValid)
            {
                var customer = new Customer();
                customer.FirstName = model.FirstName;
                customer.LastName = model.LastName;
                customer.Address = model.Address;
                _customers.Add(customer);

                model.Success = true;
                ModelState.Clear();
            }
            return View(model);
        }

        public IActionResult List()
        {
            return View(_customers.AllCustomers);
        }
    }
}
