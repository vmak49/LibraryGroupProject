﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Library.Core.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Library_GroupProject.Controllers
{
    public class TransactionController : Controller
    {
        private readonly IBookRepository _books;
        private readonly ITransactionRepository _transactions;
        private readonly ICustomerRepository _customers;

        public TransactionController(IBookRepository bookRepository, ITransactionRepository transactionRepository, ICustomerRepository customerRepository)
        {
            _books = bookRepository;
            _transactions = transactionRepository;
            _customers = customerRepository;
        }
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(TransactionViewModel model)
        {
            if (ModelState.IsValid)
            {
                var transaction = new Transaction();
                var book = _books.GetBookById(model.BookId);
                var customer = _customers.GetCustomerById(model.CustomerId);
                transaction.Book = book;
                transaction.Customer = customer;
                _transactions.Add(transaction);
                model.CustomerId = 0;
                model.CustomerId = 0;
                model.Success = true;
                ModelState.Clear();
            }
            return View(model);
        }

        public int TransactionCount(int bookId)
        {
            var transactionList = _transactions.AllTransactions.Where(t => t.Book.Id == bookId).ToList();

            return transactionList.Count();
        }

        public IActionResult List()
        {
            return View(_transactions.AllTransactions);
        }
    }
}
