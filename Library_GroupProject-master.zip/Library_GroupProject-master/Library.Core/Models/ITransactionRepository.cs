﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library.Core.Models
{
    public interface ITransactionRepository
    {
        public Transaction GetTransactionById(int id);
        IEnumerable<Transaction> AllTransactions { get; }
        IEnumerable<Transaction> TransactionsForBook(int id);
        IEnumerable<Transaction> TransactionsForCustomer(int id);
        void Add(Transaction transaction);
        void Update(Transaction transaction);
        void Delete(Transaction transaction);
    }
}
