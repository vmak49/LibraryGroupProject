﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Core.Models
{
    public class BookRepository : IBookRepository
    {
        private readonly AppDbContext _appDbContext;
        public BookRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Book> AllBooks
        {
            get
            {
                return _appDbContext.Books.Include(b => b.Transactions);
            }
        }
        public void Add(Book book)
        {
            _appDbContext.Books.Add(book);
            _appDbContext.SaveChanges();
        }
        public void Update(Book model)
        {
            Book book = _appDbContext.Books.Where(b => b.Id == model.Id).FirstOrDefault();
            book.Title = model.Title;
            book.AuthorFirstName = model.AuthorFirstName;
            book.AuthorLastName = model.AuthorLastName;
            book.Price = model.Price;

            _appDbContext.SaveChanges();

        }

        public Book GetBookById(int id)
        {
            Book book = _appDbContext.Books.Include(t => t.Transactions).Where(b => b.Id == id).FirstOrDefault();
            return book;
        }

        public void Delete(Book model)
        {
            Book book = _appDbContext.Books.Where(b => b.Id == model.Id).FirstOrDefault();

            _appDbContext.Remove(book);
            _appDbContext.SaveChanges();
        }
    }
}