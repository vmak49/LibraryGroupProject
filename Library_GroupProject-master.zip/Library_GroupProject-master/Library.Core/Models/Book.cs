﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using System.Transactions;

namespace Library.Core.Models
{
    public class Book
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public string AuthorFirstName { get; set; }
        [Required]
        public string AuthorLastName { get; set; }
        [Required, Range(0, int.MaxValue, ErrorMessage ="Enter a value greater than {0}")]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Price { get; set; }
        public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();

        public Book()
        {
        }

        public Book(int id, string title, string authorFirstName, string authorLastName, decimal price)
        {
            Id = id;
            Title = title;
            AuthorFirstName = authorFirstName;
            AuthorLastName = authorLastName;
            Price = price;
        }
    }
}
