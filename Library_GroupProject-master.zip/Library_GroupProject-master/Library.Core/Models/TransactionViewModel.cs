﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Library.Core.Models
{
    public class TransactionViewModel
    {
        [Required]
        public int BookId { get; set; }
        [Required]
        public int CustomerId { get; set; }
        public bool Success { get; set; } = false;

    }
}
