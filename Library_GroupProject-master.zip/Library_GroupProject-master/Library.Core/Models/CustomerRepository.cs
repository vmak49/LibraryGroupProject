﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library.Core.Models
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly AppDbContext _appDbContext;
        public CustomerRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public IEnumerable<Customer> AllCustomers
        {
            get
            {
                return _appDbContext.Customers.Include(c => c.Transactions);
            }
        }
        public void Add(Customer customer)
        {
            _appDbContext.Customers.Add(customer);
            _appDbContext.SaveChanges();
        }

        public void Delete(Customer customer)
        {
            _appDbContext.Customers.Remove(customer);
            _appDbContext.SaveChanges();
        }

        public Customer GetCustomerById(int id)
        {
            Customer customer = _appDbContext.Customers.Where(c => c.Id == id).FirstOrDefault();
            return customer;
        }

        public void Update(Customer model)
        {
            Customer customer = _appDbContext.Customers.Where(c => c.Id == model.Id).FirstOrDefault();
            customer.FirstName = model.FirstName;
            customer.LastName = model.LastName;
            customer.Address = model.Address;

            _appDbContext.SaveChanges();
        }
    }
}
