﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Library.Core.Models
{
    public interface ICustomerRepository
    {
        public Customer GetCustomerById(int id);
        IEnumerable<Customer> AllCustomers { get; }
        void Add(Customer customer);
        void Update(Customer customer);
        void Delete(Customer customer);
    }
}
