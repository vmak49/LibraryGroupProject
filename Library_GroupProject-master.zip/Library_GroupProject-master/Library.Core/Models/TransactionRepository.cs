﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library.Core.Models
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly AppDbContext _appDbContext;
        public TransactionRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Transaction> AllTransactions
        {
            get
            {
                return _appDbContext.Transactions.Include(b => b.Book).Include(c => c.Customer);
            }
        }

        public void Add(Transaction transaction)
        {
            _appDbContext.Transactions.Add(transaction);
            _appDbContext.SaveChanges();
        }
        public void Delete(Transaction model)
        {
            Transaction transaction = _appDbContext.Transactions.Where(t => t.Id == model.Id).FirstOrDefault();
            _appDbContext.Transactions.Remove(transaction);
            _appDbContext.SaveChanges();
        }
        public Transaction GetTransactionById(int id)
        {
            Transaction transaction = _appDbContext.Transactions.Where(t => t.Id == id).FirstOrDefault();
            return transaction;
        }

        public IEnumerable<Transaction> TransactionsForBook(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Transaction> TransactionsForCustomer(int id)
        {
            throw new NotImplementedException();
        }

        public void Update(Transaction model)
        {
            Transaction transaction = _appDbContext.Transactions.Where(t => t.Id == model.Id).FirstOrDefault();
            transaction.Book = model.Book;
            transaction.Customer = model.Customer;
            _appDbContext.SaveChanges();
        }
    }
}
