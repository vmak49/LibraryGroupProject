﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;

namespace Library.Core.Models
{
    public interface IBookRepository
    {
        public Book GetBookById(int id);

        public IEnumerable<Book> AllBooks { get; }
        public void Add(Book book);
        public void Update(Book book);
        public void Delete(Book book);

    }
}
