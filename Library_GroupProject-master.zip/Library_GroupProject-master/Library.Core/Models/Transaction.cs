﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Library.Core.Models
{
    public class Transaction
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public virtual Book Book { get; set; }
        [Required]
        public virtual Customer Customer { get; set; }
    }
}
